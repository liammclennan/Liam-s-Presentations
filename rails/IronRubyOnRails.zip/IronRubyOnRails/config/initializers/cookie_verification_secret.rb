# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '2b1b5d741327fa0cec185ec57554a257dd0b73753c32e293cd1d65e7d172706f1cc1e953000d8050639ccbe944fdfd408bd7008f4b7765cc19f1e0c11418b370';
