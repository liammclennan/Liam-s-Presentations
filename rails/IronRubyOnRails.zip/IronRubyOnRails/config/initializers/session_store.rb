# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_IronRubyOnRails_session',
  :secret      => '10192aa9184a8afe5e887ec7bbc3af236fe014789fddac03184a4de11f28aad73e8606d4de25a58165cc15cb537d4d64e90b9fcaee52493e9c153453750e0407'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
