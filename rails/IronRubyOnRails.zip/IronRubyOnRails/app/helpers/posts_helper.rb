module PostsHelper
end
