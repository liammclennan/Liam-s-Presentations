﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using NUnit.Framework;
using StoryQ;
using StoryQDemo.Core;

namespace StoryQDemo.Test
{
    [TestFixture]
    public class HashingBehaviour
    {
        private Feature hashAString = new Story("Generate a hash of a string")
            .InOrderTo("reliably generate a consistent short representation of some text")
            .AsA("application user")
            .IWant("to generate a hash of a string");

        [Test]
        public void generate_different_hashes()
        {
            hashAString
                .WithScenario("Generate different hashes")
                .Given(TheStrings, "cellar door",
                       "A man is rich in proportion to the number of things he can afford to let alone.")
                .When(AHashIsGeneratedForEachString)
                .Then(TheFirstResultIsNotEqualToTheSecondResult)
                .ExecuteWithReport(MethodBase.GetCurrentMethod());
        }

        private void TheStrings(string first, string second)
        {
            hasher = new Hasher();
            hashInput1 = first;
            hashInput2 = second;
        }

        private void AHashIsGeneratedForEachString()
        {
            firstHash = hasher.Hash(hashInput1);
            secondHash = hasher.Hash(hashInput2);
        }

        private void TheFirstResultIsNotEqualToTheSecondResult()
        {
            Assert.AreNotEqual(firstHash, secondHash);
        }

        [Test]
        public void generate_a_hash_repeatably()
        {
            hashAString
                .WithScenario("Generate a hash repeatably")
                .Given(AString, "A man is rich in proportion to the number of things he can afford to let alone.")
                .When(TheHashIsGeneratedTwice)
                .Then(TheFirstResultIsEqualToTheSecondResult)
                .ExecuteWithReport(MethodBase.GetCurrentMethod());
        }

        [Test]
        public void generate_a_hash()
        {
            hashAString
                .WithScenario("Generate a hash of a string")
                .Given(AString, "cellar door")
                .When(TheHashIsGenerated)
                .Then(TheHashIs32CharactersLong)
                .And(TheHashIsNotEqualToTheInputString)
                .ExecuteWithReport(MethodBase.GetCurrentMethod());
        }

        private void TheHashIsGeneratedTwice()
        {
            firstHash = hasher.Hash(hashInput);
            secondHash = hasher.Hash(hashInput);
        }

        private void TheFirstResultIsEqualToTheSecondResult()
        {
            Assert.AreEqual(firstHash, secondHash);
        }

        private void TheHashIsNotEqualToTheInputString()
        {
            Assert.AreNotEqual(hashInput, result);
        }

        private void TheHashIs32CharactersLong()
        {
            Assert.AreEqual(32, result.Length);
        }

        private void TheHashIsGenerated()
        {
            result = hasher.Hash(hashInput);
        }

        private void AString(string toHash)
        {
            hashInput = toHash;
            hasher = new Hasher();
        }

        private IHash hasher;
        private string hashInput;
        private string result;
        private string firstHash, secondHash;
        private string hashInput1;
        private string hashInput2;
    }
}
